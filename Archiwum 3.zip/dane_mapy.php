<?php
// JEDYNE MIEJSCE, W KTÓRYM ZARZĄDZASZ TREŚCIĄ I MAPĄ
return [
    [
        'id' => 'grota-niedzwiedzia',
        'name' => 'Grota Niedźwiedzia',
        'lat' => 50.698537, 'lon' => 19.423037,
        'image' => 'images/atrakcje/grota_niedzwiedzia.jpg',
        'short_description' => 'Odkryj prehistoryczną jaskinię, w której znaleziono szczątki mamuta i niedźwiedzia jaskiniowego.',
        'full_content' => '<h3>Grota Niedźwiedzia – Śladami Prehistorii</h3><p>Naszą podróż zaczynamy w miejscu, które pamięta czasy, gdy po Jurze stąpały niedźwiedzie jaskiniowe. Ta 70-metrowa jaskinia to prawdziwa kapsuła czasu, odkryta przez samego Zygmunta Krasińskiego. Poczuj dreszcz emocji, wchodząc do komory podpartej majestatyczną kolumną, gdzie znaleziono szczątki mamuta, nosorożca włochatego i niedźwiedzia jaskiniowego.</p>'
    ],
    [
        'id' => 'pustynia-siedlecka',
        'name' => 'Pustynia Siedlecka',
        'lat' => 50.700449, 'lon' => 19.357548,
        'image' => 'images/atrakcje/pustynia_siedlecka.jpg',
        'short_description' => 'Poczuj się jak na Saharze na tym 25-hektarowym obszarze złotego piasku, idealnym do surrealistycznych zdjęć.',
        'full_content' => '<h3>Pustynia Siedlecka – Jurajska Sahara</h3><p>Zapomnij o wszystkim, co wiesz o polskich krajobrazach. Stajesz na 25-hektarowym obszarze złotego piasku, który bardziej przypomina Saharę niż słynna Pustynia Błędowska. To idealne miejsce na surrealistyczne zdjęcia i poczucie ogromu przestrzeni, gdzie nie następuje masowe wkraczanie roślinności.</p>'
    ],
    [
        'id' => 'brama-twardowskiego',
        'name' => 'Brama Twardowskiego',
        'lat' => 50.69054, 'lon' => 19.40528,
        'image' => 'images/atrakcje/brama_twardowskiego.jpg',
        'short_description' => 'Przejdź przez magiczną, skalną bramę owianą legendą o mistrzu Twardowskim uciekającym na kogucie.',
        'full_content' => '<h3>Brama Twardowskiego – Magia w Kamieniu</h3><p>Przed Tobą jeden z najpiękniejszych ostańców Jury, owiany legendą o mistrzu Twardowskim, który miał uciekać tędy na kogucie przed diabłem. Przejdź przez tę 4-metrową, skalną bramę i poczuj magię tego miejsca, której nazwę nadał sam Zygmunt Krasiński.</p>'
    ],
    [
        'id' => 'straznica-lutowiec',
        'name' => 'Strażnica w Łutowcu',
        'lat' => 50.629100, 'lon' => 19.450230,
        'image' => 'images/atrakcje/straznica_lutowiec.jpg',
        'short_description' => 'Tajemnicze ruiny średniowiecznej wieży obronnej wzniesione na szczycie samotnej wapiennej skały.',
        'full_content' => '<h3>Strażnica w Łutowcu: Tajemnica na Skale</h3><p>Wśród jurajskich warowni strażnica w Łutowcu należy do obiektów najbardziej tajemniczych. W przeciwieństwie do wielkich zamków, nie była to nigdy okazała rezydencja, lecz surowy, czysto militarny punkt obronny. Jej pozostałości, wznoszące się na imponującym, 20-metrowym ostańcu skalnym, do dziś rozpalają wyobraźnię historyków.</p>'
    ],
    [
        'id' => 'zamek-ostreznik',
        'name' => 'Zamek Ostrężnik',
        'lat' => 50.674888, 'lon' => 19.400502,
        'image' => 'images/atrakcje/zamek_ostreznik.jpg',
        'short_description' => 'Malownicze i owiane legendą ruiny leśnego zamku z XIV wieku, nierozerwalnie połączone z Jaskinią Ostrężnicką.',
        'full_content' => '<h3>Zamek Ostrężnik: Leśna Forteca i jej Jaskinia</h3><p>Zamek Ostrężnik to obiekt niemal całkowicie wtopiony w leśny krajobraz. Jego historia, w dużej mierze nieznana z powodu braku źródeł pisanych, stała się pożywką dla licznych legend. Największym atutem tego miejsca jest nierozerwalne połączenie ruin z Jaskinią Ostrężnicką, której otwór znajduje się u podnóża zamkowej skały.</p>'
    ],
    [
        'id' => 'gory-towarne',
        'name' => 'Góry Towarne',
        'lat' => 50.768459, 'lon' => 19.271056,
        'image' => 'images/atrakcje/gory_towarne.jpg',
        'short_description' => 'Grupa bezleśnych, wapiennych wzgórz z jaskiniami, oferująca rozległe widoki na zamek w Olsztynie.',
        'full_content' => '<h3>Góry Towarne: Kupieckie Skrytki i Jurajskie Panoramy</h3><p>To idealny przykład miejsca, które łączy w sobie intrygującą legendę, wybitne walory widokowe i niewielką popularność. Nazwa nawiązuje do karawan kupieckich, które miały ukrywać swoje towary w tutejszych jaskiniach. Z ich grzbietów roztaczają się rozległe panoramy na odległy o kilka kilometrów zamek w Olsztynie.</p>'
    ],
    [
        'id' => 'zrodla-zygmunda-elzbiety',
        'name' => 'Źródła Zygmunta i Elżbiety',
        'lat' => 50.688754, 'lon' => 19.412304,
        'image' => 'images/atrakcje/zrodla_zygmunda_elzbiety.jpg',
        'short_description' => 'Romantyczne wywierzyska w Złotym Potoku, dające początek rzece Wiercicy, nazwane na cześć dzieci poety.',
        'full_content' => '<h3>Źródła Zygmunta i Elżbiety: Woda Poetów</h3><p>To miejsce o niezwykłym, romantycznym nastroju, którego wartość wynika nie tylko z piękna przyrody, ale przede wszystkim z literackiej historii nadanej mu przez Zygmunta Krasińskiego. Poeta w 1857 roku, urzeczony pięknem tego miejsca, nazwał je na cześć swoich dzieci. Woda w źródłach ma stałą temperaturę i najwyższą klasę czystości.</p>'
    ],
    [
        'id' => 'kopiec-bzowskich',
        'name' => 'Kopiec Bzowskich',
        'lat' => 50.163917, 'lon' => 19.755000,
        'image' => 'images/atrakcje/kopiec_bzowskich.jpg',
        'short_description' => 'Historyczna mogiła bohaterów narodowych z XIX wieku, oferująca zaskakującą panoramę z widokiem na Tatry.',
        'full_content' => '<h3>Kopiec Bzowskich: Mogiła z Widokiem na Tatry</h3><p>Kopiec Bzowskich w Będkowicach to obiekt wyjątkowy – nie zamek, nie skała, lecz historyczna mogiła, będąca namacalnym świadectwem losów szlacheckiego rodu i kluczowych momentów w historii Polski. Wzniesiony na wzgórzu zwanym "Na Kamyku", jest miejscem spoczynku ojca i syna. Dziś, poza wartością historyczną, kopiec jest przede wszystkim fantastycznym punktem widokowym. Przy dobrej pogodzie można stąd podziwiać nie tylko panoramę Krakowa, ale nawet odległe szczyty Tatr. Łatwe, kilkuminutowe dojście spod remizy strażackiej w Będkowicach czyni go atrakcją dostępną dla każdego.</p>'
    ],
    [
        'id' => 'pustelnia-salomei',
        'name' => 'Pustelnia Błogosławionej Salomei',
        'lat' => 50.231111, 'lon' => 19.825556,
        'image' => 'images/atrakcje/pustelnia_salomei.jpg',
        'short_description' => 'Ukryty w Grodzisku barokowy kompleks sakralny z XVII wieku, wznoszący się na skale nad Doliną Prądnika.',
        'full_content' => '<h3>Pustelnia Błogosławionej Salomei: Barokowa Perła w Grodzisku</h3><p>Ukryta na urwistej skale nad Doliną Prądnika, Pustelnia Błogosławionej Salomei jest miejscem o głębokim wymiarze duchowym, często pomijanym przez turystów zmierzających do serca Ojcowskiego Parku Narodowego. Jest to jeden z najciekawszych, a wciąż mało znanych, XVII-wiecznych kompleksów zabytkowych w regionie. Dodatkową osobliwością jest unikatowa, kamienna figura słonia z 1686 roku.</p>'
    ],
    [
        'id' => 'mlyn-kolaczew',
        'name' => 'Młyn Kołaczew',
        'lat' => 50.698056, 'lon' => 19.423611,
        'image' => 'images/atrakcje/mlyn_kolaczew.jpg',
        'short_description' => 'Zabytkowy, drewniany młyn wodny z początku XIX wieku, położony w sercu Rezerwatu Parkowe w Złotym Potoku.',
        'full_content' => '<h3>Młyn Kołaczew: Drewniane Serce Złotego Potoku</h3><p>Młyn Kołaczew to cenny zabytek dziedzictwa przemysłowego, który opowiada historię regionu nie przez pryzmat wojen i obronności, lecz gospodarki i techniki. Jako obiekt na Szlaku Architektury Drewnianej województwa śląskiego, stanowi ważny punkt na kulturalnej mapie Jury. Położony jest w malowniczym sercu Rezerwatu Parkowe w Złotym Potoku, nad brzegiem Stawu Zielonego (nazywanego też Snem Nocy Letniej), na rzece Wiercicy.</p>'
    ],
    [
        'id' => 'gora-biaklo',
        'name' => 'Góra Biakło',
        'lat' => 50.738110, 'lon' => 19.272070,
        'image' => 'images/atrakcje/gora_biaklo.jpg',
        'short_description' => 'Charakterystyczne wzgórze z krzyżem na szczycie, nazywane "Jurajskim Giewontem", z którego roztacza się panorama okolicy.',
        'full_content' => '<h3>Góra Biakło: Jurajski Giewont z Widokiem na Olsztyn</h3><p>Góra Biakło to prawdziwy fenomen jurajskiego krajobrazu. Mimo niewielkiej wysokości bezwzględnej (340 m n.p.m.), zyskała status miejsca kultowego dzięki swojemu charakterystycznemu kształtowi, który do złudzenia przypomina tatrzański Giewont. Podobieństwo to podkreśla metalowy krzyż na szczycie, postawiony dla upamiętnienia pontyfikatu Jana Pawła II. Nagrodą za niewielki wysiłek jest spektakularna, 360-stopniowa panorama.</p>'
    ],
    [
        'id' => 'skaly-rzedkowickie',
        'name' => 'Skały Rzędkowickie',
        'lat' => 50.573610, 'lon' => 19.491740,
        'image' => 'images/atrakcje/skaly_rzedkowickie.jpg',
        'short_description' => 'Długi na kilometr, malowniczy wał skalny, będący rajem dla wspinaczy i celem spacerów wśród fantazyjnych ostańców.',
        'full_content' => '<h3>Skały Rzędkowickie: Kamienny Wał dla Wspinaczy i Wędrowców</h3><p>Skały Rzędkowickie, choć doskonale znane w środowisku wspinaczkowym, często pozostają poza radarem przeciętnego turysty. Niesłusznie, gdyż oferują jedne z najbardziej malowniczych i monumentalnych formacji skalnych na całej Jurze. Tworzą one długi na ponad kilometr, zwarty wał białych ostańców, wznoszący się dumnie nad wsią Rzędkowice. Wśród licznych skał wyróżnia się strzelista iglica zwana Wysoką, u której stóp znajduje się ołtarz polowy, oraz Okiennik Rzędkowicki – skała z charakterystycznym otworem.</p>'
    ],
    [
        'id' => 'dolina-wodacej',
        'name' => 'Dolina Wodącej',
        'lat' => 50.428261, 'lon' => 19.674333,
        'image' => 'images/atrakcje/dolina_wodacej.jpg',
        'short_description' => 'Unikatowa, sucha dolina krasowa ze słynnymi Zegarowymi Skałami i jaskiniami kryjącymi najstarsze ślady człowieka w Polsce.',
        'full_content' => '<h3>Dolina Wodącej: Sucha Rzeka i Szepczące Jaskinie</h3><p>Dolina Wodącej wyróżnia się na tle innych jurajskich dolin unikatowym charakterem geologicznym. Jest to tzw. dolina sucha – na jej dnie nie płynie żaden stały potok, co jest zjawiskiem typowym dla krasowego, przepuszczalnego podłoża wapiennego. Położona między zamkiem w Smoleniu a wsią Domaniewice, stanowi skarbnicę przyrodniczych i historycznych atrakcji. Jej największymi magnesami są Zegarowe Skały – imponująca grupa ostańców, uznana za pomnik przyrody. W ich wnętrzu kryją się dwie znane jaskinie: Jaskinia Zegarowa, której nazwa pochodzi od legendy o zegarze bijącym w wigilijne noce, oraz Jaskinia Jasna, duża i dobrze oświetlona grota.</p>'
    ],
    [
        'id' => 'wawoz-polrzeczki',
        'name' => 'Wąwóz Półrzeczki',
        'lat' => 50.068812, 'lon' => 19.706944,
        'image' => 'images/atrakcje/wawoz_polrzeczki.jpg',
        'short_description' => 'Cichy i zalesiony wąwóz wapienny, stanowiący spokojną alternatywę dla popularnej Doliny Mnikowskiej.',
        'full_content' => '<h3>Wąwóz Półrzeczki: Cichy Sąsiad Doliny Mnikowskiej</h3><p>Dla poszukiwaczy ciszy i spokoju Wąwóz Półrzeczki jest prawdziwym odkryciem. Położony tuż naprzeciwko słynnej i często zatłoczonej Doliny Mnikowskiej, jest przez większość turystów całkowicie pomijany. Ta kameralność stanowi o jego wyjątkowym uroku. Znajduje się we wsi Mników, na terenie Tenczyńskiego Parku Krajobrazowego. Wąwóz ma postać zalesionej, głęboko wciętej w wapienne skały doliny, na której dnie płynie niewielki strumień. Trasa prowadząca przez wąwóz to szeroki i wygodny trakt spacerowy, pozbawiony stromych podejść, co czyni go idealnym miejscem na relaksującą przechadzkę. Wąwóz urozmaicają liczne, strome ściany skalne, popularne wśród wspinaczy, oraz kilka jaskiń, z których największa i najłatwiej dostępna to Jaskinia na Łopiankach.</p>'
    ],
    [
        'id' => 'rezerwat-zielona-gora',
        'name' => 'Rezerwat "Zielona Góra" i Jeziorko Krasowe',
        'lat' => 50.777456, 'lon' => 19.233583,
        'image' => 'images/atrakcje/rezerwat_zielona_gora.jpg',
        'short_description' => 'Leśny rezerwat z ciekawymi formacjami skalnymi oraz unikatowym, okresowym jeziorkiem krasowym u jego podnóża.',
        'full_content' => '<h3>Rezerwat "Zielona Góra" i Jeziorko Krasowe: Geologiczny Unikat</h3><p>Wycieczka do Rezerwatu "Zielona Góra" i pobliskiego Jeziorka Krasowego to propozycja "dwa w jednym", pozwalająca poznać zarówno leśny, skalisty charakter Jury, jak i zobaczyć unikatowe w skali kraju zjawisko hydrogeologiczne. Rezerwat "Zielona Góra", utworzony w 1953 roku, chroni wapienne wzgórze o wysokości 342 m n.p.m., porośnięte malowniczym lasem bukowo-sosnowym. Prawdziwą osobliwością jest jednak Jeziorko Krasowe – zbiornik wodny, który powstał w naturalnym leju krasowym. Jest to zjawisko unikatowe w Polsce, występujące poza Jurą jedynie na Wyżynie Lubelskiej. Poziom wody w jeziorku jest zmienny i zależy bezpośrednio od ilości opadów atmosferycznych.</p>'
    ],
    [
        'id' => 'skala-milosc',
        'name' => 'Skała Miłości w Mstowie',
        'lat' => 50.829510, 'lon' => 19.291110,
        'image' => 'images/atrakcje/skala_milosc.jpg',
        'short_description' => 'Potężny ostaniec nad Wartą, z którym związana jest lokalna legenda i wokół którego stworzono tereny rekreacyjne.',
        'full_content' => '<h3>Skała Miłości w Mstowie: Legenda Zapisana w Kamieniu</h3><p>Siła przyciągania Skały Miłości w Mstowie tkwi w idealnym połączeniu trzech elementów: malowniczego ostańca, chwytającej za serce legendy i doskonale zagospodarowanego terenu rekreacyjnego. Jest to potężna, samotna skała wapienna, wznosząca się tuż nad brzegiem Warty. Uważa się ją za najdalej na północ wysunięty ostaniec całej Jury Krakowsko-Częstochowskiej. Swoją nazwę i tożsamość zawdzięcza lokalnej legendzie. Dziś wokół skały rozciągają się tereny rekreacyjne ze ścieżkami spacerowymi, altanami, miejscem na ognisko, a nawet schodami prowadzącymi na punkt widokowy na szczycie.</p>'
    ],
    [
        'id' => 'zalew-dzibice',
        'name' => 'Zalew w Dzibicach',
        'lat' => 50.595027, 'lon' => 19.561307,
        'image' => 'images/atrakcje/zalew_dzibice.jpg',
        'short_description' => 'Sztuczny zbiornik wodny otoczony lasami, oferujący piaszczystą plażę i wytchnienie od skalistego krajobrazu Jury.',
        'full_content' => '<h3>Zalew w Dzibicach: Wodny Akcent na Wapiennym Szlaku</h3><p>Zalew w Dzibicach (zwany też Zalewem Kostkowice) to ciekawy kontrapunkt dla typowo skalistego i "suchego" krajobrazu Jury. Ten sztuczny zbiornik wodny, stworzony na rzece Białce w gminie Kroczyce, stał się popularnym, choć wciąż głównie lokalnym, miejscem rekreacji. Składa się z kompleksu czterech połączonych stawów. W sezonie letnim przyciąga amatorów plażowania i kąpieli – znajduje się tu duża, piaszczysta plaża, kąpielisko oraz możliwość wypożyczenia sprzętu wodnego, takiego jak kajaki czy łódki. Całość otoczona jest lasami i położona malowniczo u stóp Skał Kroczyckich. Poza sezonem i w dni powszednie miejsce to zamienia się w oazę ciszy, idealną do spacerów, obserwacji ptactwa wodnego i wędkowania.</p>'
    ],
    [
        'id' => 'dziurawa-skala',
        'name' => 'Dziurawa Skała',
        'lat' => 50.425531, 'lon' => 19.663483,
        'image' => 'images/atrakcje/dziurawa_skala.jpg',
        'short_description' => 'Unikatowa forma skalna z charakterystycznym otworem, powstałym w wyniku procesów wietrzenia wapieni jurajskich.',
        'full_content' => '<h3>Dziurawa Skała – Gmina Klucze</h3><p>Forma denudacyjna z charakterystycznym otworem powstałym w wyniku procesów wietrzenia wapieni jurajskich. Ciekawy przykład rzeźby krasowej w środkowej części Jury Krakowsko-Częstochowskiej.</p>'
    ],
    [
        'id' => 'ostaniec-dupna',
        'name' => 'Ostaniec Dupna',
        'lat' => 50.179197, 'lon' => 19.785925,
        'image' => 'images/atrakcje/ostaniec_dupna.jpg',
        'short_description' => 'Forma denudacyjna o charakterystycznym kształcie, będąca elementem typowego krajobrazu jurajskiego.',
        'full_content' => '<h3>Ostaniec Dupna – Olkusz</h3><p>Forma denudacyjna o charakterystycznym kształcie, będąca elementem typowego krajobrazu jurajskiego. Przykład ostańca wapiennego w południowej części Wyżyny Krakowsko-Częstochowskiej.</p>'
    ],
    [
        'id' => 'zubowe-skaly',
        'name' => 'Zubowe Skały (Rezerwat Pazurek)',
        'lat' => 50.334722, 'lon' => 19.488333,
        'image' => 'images/atrakcje/zubowe_skaly.jpg',
        'short_description' => 'Grupa ostańców o spiczastych kształtach z ścieżką dydaktyczną przez bukowy las. Legenda mówi o skarbach ukrytych przez powstańców styczniowych.',
        'full_content' => '<h3>Zubowe Skały (Rezerwat Pazurek) – Wieś Pazurek</h3><p>Grupa ostańców o spiczastych kształtach (pazurkach) z ścieżką dydaktyczną przez bukowy las. Nazwa rezerwatu pochodzi od charakterystycznych spiczastych form skalnych. Legenda mówi o skarbach ukrytych przez powstańców styczniowych.</p>'
    ],
    [
        'id' => 'diabelskie-mosty',
        'name' => 'Diabelskie Mosty',
        'lat' => 50.684985, 'lon' => 19.410874,
        'image' => 'images/atrakcje/diabelskie_mosty.jpg',
        'short_description' => '15-metrowy ostaniec z głębokimi szczelinami i tunelem, miejsce historycznej akcji partyzanckiej AK.',
        'full_content' => '<h3>Diabelskie Mosty – Złoty Potok</h3><p>15-metrowy ostaniec z głębokimi szczelinami i tunelem o długości 8 metrów. Miejsce historycznej akcji partyzanckiej AK - zamachu na "Krwawego Julka" 9 listopada 1944 roku. Związane legendą z Twardowskim.</p>'
    ],
    [
        'id' => 'jezioro-krasowe',
        'name' => 'Jezioro Krasowe w Kusitach',
        'lat' => 50.613889, 'lon' => 19.480556,
        'image' => 'images/atrakcje/jezioro_krasowe.jpg',
        'short_description' => 'Unikatowe w skali kraju jezioro krasowe powstałe w procesach krasowych, w malowniczym otoczeniu wapiennych ostańców.',
        'full_content' => '<h3>Jezioro Krasowe w Kusitach – Kusięta</h3><p>Unikatowe w skali kraju jezioro krasowe powstałe w procesach krasowych. Znajduje się w malowniczym otoczeniu wapiennych ostańców i jest częścią lokalnego ekosystemu jurajskiego.</p>'
    ],
    [
        'id' => 'sokole-gory',
        'name' => 'Sokole Góry (kompleks jaskiń)',
        'lat' => 50.731736, 'lon' => 19.265074,
        'image' => 'images/atrakcje/sokole_gory.jpg',
        'short_description' => 'Ponad 200-hektarowy rezerwat z najgłębszą jaskinią Jury - Studnisko (77,5 m głębokości) i systemem kilkudziesięciu jaskiń.',
        'full_content' => '<h3>Sokole Góry (kompleks jaskiń) – Olsztyn</h3><p>Ponad 200-hektarowy rezerwat z najgłębszą jaskinią Jury - Studnisko (77,5 m głębokości). Kompleks zawiera kilkadziesiąt jaskiń, w tym system Wszystkich Świętych i Olsztyńskiej - jeden z największych na Jurze.</p>'
    ],
    [
        'id' => 'staw-amerykan',
        'name' => 'Rezerwat Parkowe - Staw Amerykan',
        'lat' => 50.692500, 'lon' => 19.417500,
        'image' => 'images/atrakcje/staw_amerykan.jpg',
        'short_description' => 'Malowniczy staw będący początkiem rezerwatu Parkowe, chroniącego najbardziej fascynującą część doliny Wiercicy.',
        'full_content' => '<h3>Rezerwat Parkowe - Staw Amerykan – Złoty Potok</h3><p>Malowniczy staw będący początkiem rezerwatu Parkowe, chroniącego najbardziej fascynującą część doliny Wiercicy. Popularne miejsce rekreacji latem, z polami namiotowymi i lokalną gastronomią specjalizującą się w pstrągach.</p>'
    ]
];