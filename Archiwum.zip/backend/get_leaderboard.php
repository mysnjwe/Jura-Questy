<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: https://juraquest.pl'); // Pozwól na żądania tylko z Twojej domeny
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Obsługa preflight request dla CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

$servername = "localhost";
$username = "srv90026_juraquest_db";
$password = "Qp7xD49KpgyUpEpUMSB9";
$dbname = "srv90026_juraquest_db";

// Utwórz połączenie
$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdź połączenie
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Pobierz 10 najlepszych wyników (najkrótszy czas, najwyższy wynik)
$sql = "SELECT team_name, completion_time_seconds, score FROM game_stats ORDER BY score DESC, completion_time_seconds ASC LIMIT 10";
$result = $conn->query($sql);

$leaderboard = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $leaderboard[] = $row;
    }
}

echo json_encode(["success" => true, "leaderboard" => $leaderboard]);

$conn->close();
?>