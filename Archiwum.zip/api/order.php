<?php

<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Metoda żądania musi być POST.']);
    exit;
}

$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$gameId = htmlspecialchars($_POST['gameId'] ?? 'Nieznana Gra');
$amount = 7900; // Kwota w groszach (79.00 PLN)

if (!$email) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Brak poprawnego adresu e-mail.']);
    exit;
}

// 1. Przygotowanie danych do Przelewy24
$sessionId = uniqid('juraquest_', true);
$description = "Zamówienie gry: {$gameId}";
$urlReturn = "https://juraquest.pl/dziekujemy.html?session={$sessionId}";
$urlStatus = "https://juraquest.pl/api/p24_notification.php"; // Upewnij się, że ten URL jest publicznie dostępny

// 2. Tworzenie sygnatury (sign)
$crc = P24_CRC_KEY;
$sign = hash('sha384', json_encode([
    "sessionId" => $sessionId,
    "merchantId" => P24_MERCHANT_ID,
    "amount" => $amount,
    "currency" => "PLN",
    "crc" => $crc
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

// 3. Przygotowanie parametrów do wysłania
$p24_data = [
    "merchantId" => P24_MERCHANT_ID,
    "posId" => P24_POS_ID,
    "sessionId" => $sessionId,
    "amount" => $amount,
    "currency" => "PLN",
    "description" => $description,
    "email" => $email,
    "country" => "PL",
    "language" => "pl",
    "urlReturn" => $urlReturn,
    "urlStatus" => $urlStatus,
    "sign" => $sign
];

// 4. Komunikacja z API Przelewy24 w celu zarejestrowania transakcji
$ch = curl_init(P24_URL . 'api/v1/transaction/register');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($p24_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Basic ' . base64_encode(P24_POS_ID . ':' . P24_API_KEY)
]);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$responseData = json_decode($response, true);

if ($httpcode === 201 && isset($responseData['data']['token'])) {
    // 5. Przekierowanie użytkownika do bramki płatniczej
    $redirectUrl = P24_URL . 'trnRequest/' . $responseData['data']['token'];
    echo json_encode(['status' => 'success', 'redirectUrl' => $redirectUrl]);
} else {
    // Logowanie błędu do pliku dla celów deweloperskich
    $log_message = "Błąd rejestracji transakcji P24: HTTP Code: {$httpcode} | Response: {$response}\n";
    error_log($log_message, 3, '../backend.log');

    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Nie udało się zainicjować płatności. Spróbuj ponownie później.']);
}

?>

?>