<?php
// USTAWIENIA PRZELEWY24 - SANDBOX (TESTOWE)

// Ustawienia dla środowiska testowego (sandbox)
define('P24_SANDBOX', true); // true dla sandbox, false dla produkcji

// Dane Twojego konta Przelewy24
define('P24_MERCHANT_ID', '352184'); // Zastąp swoim ID sprzedawcy (tym, którym się logujesz)
define('P24_POS_ID', '352184');      // Zazwyczaj to samo co Merchant ID
define('P24_CRC_KEY', '3126e951966129f6');
define('P24_API_KEY', '56e793e0417454bf4c69cdfade8fdc11');

// Adresy URL Przelewy24
if (P24_SANDBOX) {
    define('P24_URL', 'https://sandbox.przelewy24.pl/');
} else {
    define('P24_URL', 'https://secure.przelewy24.pl/');
}

// Ustawienia bazy danych (jeśli będziesz używać)
// define('DB_HOST', 'localhost');
// define('DB_USER', 'root');
// define('DB_PASS', 'password');
// define('DB_NAME', 'juraquest');

// Ustawienia e-mail
define('SMTP_HOST', 'h61.seohost.pl');
define('SMTP_USERNAME', 'kontakt@juraquest.pl');
define('SMTP_PASSWORD', 'kygrab-0dymca-cIhjeq');
define('SMTP_PORT', 465);
define('SMTP_FROM_EMAIL', 'no-reply@juraquest.pl');
define('SMTP_FROM_NAME', 'Jura Quest');

?>
