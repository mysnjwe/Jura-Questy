<?php
require_once 'config.php';

// Funkcja do logowania z datą i godziną
function log_to_file($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . "\n", 3, '../backend.log');
}

header('Content-Type: application/json');

log_to_file("order.php: Skrypt uruchomiony.");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    log_to_file("order.php: Błąd - nieprawidłowa metoda HTTP: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode(['status' => 'error', 'message' => 'Metoda żądania musi być POST.']);
    exit;
}
log_to_file("order.php: Metoda POST poprawna.");

$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$gameId = htmlspecialchars($_POST['gameId'] ?? 'Nieznana Gra');
$amount = 499; // Kwota w groszach (4.99 PLN)

if (!$email) {
    http_response_code(400);
    log_to_file("order.php: Błąd - nieprawidłowy lub pusty e-mail.");
    echo json_encode(['status' => 'error', 'message' => 'Brak poprawnego adresu e-mail.']);
    exit;
}
log_to_file("order.php: E-mail poprawny: {$email}");

// 1. Przygotowanie danych do Przelewy24
$sessionId = uniqid('juraquest_', true);
$description = "Zamówienie gry: {$gameId}";
$urlReturn = "https://juraquest.pl/dziekujemy.html?session={$sessionId}";
$urlStatus = "https://juraquest.pl/api/p24_notification.php";

log_to_file("order.php: Sesja {$sessionId} przygotowana.");

// 2. Tworzenie sygnatury (sign)
$crc = P24_CRC_KEY;
$sign_data = [
    "sessionId" => $sessionId,
    "merchantId" => (int)P24_MERCHANT_ID,
    "amount" => $amount,
    "currency" => "PLN",
    "crc" => $crc
];
$sign = hash('sha384', json_encode($sign_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

log_to_file("order.php: Sygnatura dla sesji {$sessionId} wygenerowana.");

// 3. Przygotowanie parametrów do wysłania
$p24_data = [
    "merchantId" => (int)P24_MERCHANT_ID,
    "posId" => (int)P24_POS_ID,
    "sessionId" => $sessionId,
    "amount" => $amount,
    "currency" => "PLN",
    "description" => $description,
    "email" => $email,
    "country" => "PL",
    "language" => "pl",
    "urlReturn" => $urlReturn,
    "urlStatus" => $urlStatus,
    "sign" => $sign
];

log_to_file("order.php: Dane do wysłania: " . json_encode($p24_data));

// 4. Komunikacja z API Przelewy24
$register_url = P24_URL . 'api/v1/transaction/register';
log_to_file("order.php: Inicjuję cURL do: {$register_url}");

$ch = curl_init($register_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($p24_data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Basic ' . base64_encode(P24_POS_ID . ':' . P24_API_KEY)
]);
// Dodanie opcji timeout
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

log_to_file("order.php: cURL wykonany. HTTP Code: {$httpcode}. cURL Error: {$curl_error}. Raw Response: {$response}");

$responseData = json_decode($response, true);

if (($httpcode === 200 || $httpcode === 201) && isset($responseData['data']['token'])) {
    $redirectUrl = P24_URL . 'trnRequest/' . $responseData['data']['token'];
    log_to_file("order.php: Sukces! Token otrzymany. Przekierowanie na: {$redirectUrl}");
    echo json_encode(['status' => 'success', 'redirectUrl' => $redirectUrl]);
} else {
    log_to_file("order.php: BŁĄD REJESTRACJI TRANSAKCJI. HTTP Code: {$httpcode} | cURL Error: {$curl_error} | Response: {$response}");
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Nie udało się zainicjować płatności. Spróbuj ponownie później.']);
}

?>