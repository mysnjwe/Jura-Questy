<?php

$servername = "localhost";
$username = "srv90026_juraquest_db";
$password = "Qp7xD49KpgyUpEpUMSB9";
$dbname = "srv90026_juraquest_db";

// Utwórz połączenie
$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdź połączenie
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}

// SQL do utworzenia tabeli orders
$sql = "CREATE TABLE IF NOT EXISTS orders (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(255) NOT NULL UNIQUE,
    game_id VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    access_code VARCHAR(255) NOT NULL,
    payment_status VARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Tabela orders utworzona pomyślnie lub już istnieje.";
} else {
    echo "Błąd podczas tworzenia tabeli: " . $conn->error;
}

$conn->close();

?>