<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer-6.9.1/src/Exception.php';
require 'PHPMailer/PHPMailer-6.9.1/src/PHPMailer.php';
require 'PHPMailer/PHPMailer-6.9.1/src/SMTP.php';

header('Content-Type: application/json');

// Sprawdź, czy żądanie jest typu POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Metoda żądania musi być POST.']);
    exit;
}

// Pobierz dane z żądania POST
$customerEmail = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$gameId = $_POST['gameId'] ?? '';
$accessCodeInput = $_POST['accessCode'] ?? ''; // Nowe pole na kod dostępu

$isFreeAccess = false;
$generatedAccessCode = ''; // Kod, który zostanie wysłany

// --- Logika obsługi kodu dostępu lub e-maila ---
if (!empty($accessCodeInput)) {
    // Użytkownik podał kod dostępu
    $HARDCODED_TEST_CODE = "JURATEST"; // <--- TWÓJ HARDKODOWANY KOD TESTOWY

    if (strtoupper($accessCodeInput) === $HARDCODED_TEST_CODE) {
        $isFreeAccess = true;
        // Generujemy nowy kod dostępu do gry, który zostanie wysłany
        $generatedAccessCode = strtoupper(bin2hex(random_bytes(4)));
        // W prawdziwej aplikacji tutaj sprawdzilibyśmy, czy kod testowy nie został już użyty
        // i oznaczylibyśmy go jako użyty w bazie danych.
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Podany kod dostępu jest nieprawidłowy.']);
        exit;
    }
} else {
    // Użytkownik nie podał kodu dostępu, więc oczekujemy adresu e-mail do zakupu
    if (!$customerEmail) {
        echo json_encode(['status' => 'error', 'message' => 'Brak poprawnego adresu e-mail.']);
        exit;
    }
    // Tutaj w przyszłości będzie logika inicjacji płatności Przelewy24
    // Na razie, dla testów, generujemy kod i wysyłamy e-mail
    $generatedAccessCode = strtoupper(bin2hex(random_bytes(4)));
}

// --- Konfiguracja PHPMailer ---
$mail = new PHPMailer(true);

try {
    // Ustawienia serwera SMTP (Zmień na swoje dane!)
    $mail->isSMTP();
    $mail->Host       = 'h61.seohost.pl';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'kontakt@juraquest.pl';
    $mail->Password   = 'kygrab-0dymca-cIhjeq';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;

    // Nadawca i odbiorca
    $mail->setFrom('no-reply@juraquest.pl', 'Jura Quest'); // Zmień na swój adres nadawcy
    $mail->addAddress($customerEmail); // Adres e-mail klienta

    // Treść e-maila
    $mail->isHTML(true);
    $mail->Subject = 'Twoj kod dostepu do gry Jura Quest!';
    $mail->Body    = '
        <h1>Dziekujemy za zakup gry Jura Quest!</h1>
        <p>Twoj kod dostepu do gry \'' . htmlspecialchars($gameId) . '\' to: <strong>' . $generatedAccessCode . '</strong></p>
        <p>Aby rozpocząć przygodę, wykonaj następujące kroki:</p>
        <ol>
            <li>Otwórz skaner QR Jura Quest: <a href="https://juraquest.pl/qr-scanner.html">https://juraquest.pl/qr-scanner.html</a></li>
            <li>Zeskanuj pierwszy kod QR na rynku we Włodowicach (lub inny kod startowy dla Twojej gry).</li>
            <li>Gdy aplikacja poprosi o kod dostępu, wpisz powyższy kod.</li>
            <li>Rozpocznij swoją przygodę!</li>
        </ol>
        <p>W razie problemow, skontaktuj sie z nami.</p>
        <p>Pozdrawiamy,<br>Zespół Jura Quest</p>
    ';
    $mail->AltBody = 'Twoj kod dostepu do gry ' . $gameId . ' to: ' . $generatedAccessCode . '. Otworz https://juraquest.pl/qr-scanner.html i postepuj zgodnie z instrukcjami.';

    $mail->send();
    echo json_encode(['status' => 'success', 'message' => 'Kod dostępu wysłany na Twój adres e-mail.']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => "Wysyłka e-maila nie powiodła się. Mailer Error: {$mail->ErrorInfo}"]);
}

?>