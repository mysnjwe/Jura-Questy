const CACHE_NAME = 'jura-quest-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/css/style.css',
  '/js/main.js',
  '/nasze-gry.html',
  '/cennik.html',
  '/dla-partnerow.html',
  '/blog.html',
  '/kontakt.html',
  '/polityka-prywatnosci.html',
  '/regulamin.html',
  // Dodaj inne pliki, które chcesz buforować, np. obrazy, czcionki
  // '/images/logo.png',
  // '/images/icons/icon-192x192.png',
  // '/images/icons/icon-512x512.png',
  // Pamiętaj o ścieżkach do obrazów używanych w sekcji 'Polecane Questy' i 'Dla Kogo'
  // np. 'https://upload.wikimedia.org/wikipedia/commons/0/0c/JuDrone_Palac_Wlodowice.jpg'
  // Należy pamiętać, że zewnętrzne zasoby (CDN, inne domeny) mogą wymagać specjalnej obsługi w Service Workerze
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request)
      .then(response => {
        // If network request succeeds, clone the response and put it in cache
        const responseClone = response.clone();
        caches.open(CACHE_NAME).then(cache => {
          cache.put(event.request, responseClone);
        });
        return response;
      })
      .catch(() => {
        // If network request fails, try to get from cache
        return caches.match(event.request);
      })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});